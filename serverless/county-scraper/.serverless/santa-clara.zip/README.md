#Structure

##Deployment
- Navigate to Serverless


## Changing schedule
- go to http://www.cronmaker.com/
- write the frequency you want to have
- add it to serverless.yml under events >> schedule 